PODLAHOVKA WEB V2.1
===================

Toto je webová verzia kalkulačky. Po nasadení ju otvoríš cez obyčajnú webovú adresu v Chrome/Safari na PC aj mobile.

ČO VIE
- nahrať PDF projektu
- AI prečíta text aj výkresové strany PDF
- vyhľadá strany vykurovania
- vytiahne miestnosti, plochy a dostupné projektové údaje
- zobrazí kontrolnú tabuľku
- po potvrdení prenesie údaje do kalkulačky
- vytvorí kusovník podlahového vykurovania
- počíta aj kaučukovú izoláciu 28x13 mm na prívod/spiatočku

DÔLEŽITÉ
API kľúč sa nevkladá do stránky. Nastaví sa iba raz na serveri ako OPENAI_API_KEY.
Potom pri bežnom používaní na mobile ani notebooku nič nezadávaš.

NASADENIE NA RENDER (jedna z možností)
1. Nahraj celý tento priečinok do súkromného GitHub repozitára.
2. Na Render vytvor nový Web Service z repozitára.
3. Build command: pip install -r requirements.txt
4. Start command: gunicorn app:app --bind 0.0.0.0:$PORT --timeout 240
5. V Environment pridaj OPENAI_API_KEY.
6. Deploy.
7. Render ti vytvorí webovú adresu. Tú potom otvoríš na PC aj iPhone.

LOKÁLNY TEST (voliteľné)
1. Python 3.11+
2. pip install -r requirements.txt
3. skopíruj .env.example na .env a vlož kľúč
4. python app.py
5. otvor http://127.0.0.1:8080

Poznámka: AI nemá hádať chýbajúce technické údaje. Nejasné alebo chýbajúce hodnoty nechá prázdne/0 a používateľ ich skontroluje.
