import base64
import json
import os
from pathlib import Path

import requests
from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request

load_dotenv()

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6").strip()

SCHEMA = {
    "type": "object",
    "properties": {
        "project_name": {"type": "string"},
        "heating_pages": {"type": "array", "items": {"type": "integer"}},
        "notes": {"type": "array", "items": {"type": "string"}},
        "rooms": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "floor": {"type": "string"},
                    "room_no": {"type": "string"},
                    "name": {"type": "string"},
                    "area_m2": {"type": "number"},
                    "floor_finish": {"type": "string"},
                    "spacing_mm": {"type": "integer"},
                    "loops": {"type": "integer"},
                    "loop_lengths_m": {"type": "array", "items": {"type": "number"}},
                    "manifold": {"type": "string"},
                    "flow_l_min": {"type": "number"},
                    "heat_w": {"type": "number"},
                    "distance_to_manifold_m": {"type": "number"},
                    "exterior_wall_m": {"type": "number"},
                    "door_crossings": {"type": "integer"},
                    "french_window": {"type": "boolean"},
                    "confidence": {"type": "number"},
                    "source_note": {"type": "string"}
                },
                "required": [
                    "floor", "room_no", "name", "area_m2", "floor_finish",
                    "spacing_mm", "loops", "loop_lengths_m", "manifold",
                    "flow_l_min", "heat_w", "distance_to_manifold_m",
                    "exterior_wall_m", "door_crossings", "french_window",
                    "confidence", "source_note"
                ],
                "additionalProperties": False
            }
        }
    },
    "required": ["project_name", "heating_pages", "notes", "rooms"],
    "additionalProperties": False
}

PROMPT = """Si technický extraktor projektov podlahového vykurovania.
Analyzuj celý priložený PDF projekt, vrátane textovej vrstvy aj obrázkov strán.
Najprv identifikuj strany, ktoré sa týkajú ÚSTREDNÉHO VYKUROVANIA / PODLAHOVÉHO VYKUROVANIA.
Potom vytiahni po jednotlivých miestnostiach iba údaje, ktoré sú v projekte skutočne uvedené alebo ich možno priamo odčítať z výkresu.

Pravidlá:
- Nehádať technické údaje. Ak údaj v projekte nie je, použi 0 alebo prázdny reťazec/pole podľa typu.
- area_m2: plocha miestnosti z legendy/tabuľky.
- spacing_mm: rozstup podlahovky iba ak je uvedený alebo jednoznačne označený. Inak 0.
- loops: počet okruhov iba ak je uvedený alebo jednoznačne zakreslený. Inak 0.
- loop_lengths_m: presné dĺžky okruhov iba ak sú uvedené. Inak [].
- manifold: označenie rozdeľovača/zberača (napr. RZ1) iba ak sa dá určiť.
- flow_l_min, heat_w: iba projektové hodnoty; inak 0.
- distance_to_manifold_m, exterior_wall_m, door_crossings, french_window: vyplň iba keď to možno spoľahlivo priamo odčítať z výkresu; inak 0/false.
- floor_finish: typ podlahy z legendy, ak je uvedený.
- confidence: 0 až 1 podľa istoty konkrétneho riadku.
- source_note: krátko uveď, z čoho bol riadok prečítaný (napr. 'legenda miestností, str. 13').
- Zachovaj všetky miestnosti relevantné pre vykurovanie, aj keď niektoré údaje chýbajú.
- Nezamieňaj zdravotechniku, vodovod a kanalizáciu za vykurovanie.
"""


def extract_output_text(payload: dict) -> str:
    # Responses API REST payload: output[] -> content[] -> output_text.text
    chunks = []
    for item in payload.get("output", []):
        for content in item.get("content", []) or []:
            if content.get("type") == "output_text" and content.get("text"):
                chunks.append(content["text"])
    return "\n".join(chunks).strip()


@app.get("/")
def index():
    return render_template("index.html", model=OPENAI_MODEL)


@app.post("/api/analyze")
def analyze():
    if not OPENAI_API_KEY:
        return jsonify({"error": "Na serveri nie je nastavený OPENAI_API_KEY."}), 500

    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"error": "Chýba PDF súbor."}), 400
    if not f.filename.lower().endswith(".pdf"):
        return jsonify({"error": "Nahraj PDF súbor."}), 400

    data = f.read()
    if not data:
        return jsonify({"error": "PDF je prázdne."}), 400
    if len(data) > 50 * 1024 * 1024:
        return jsonify({"error": "PDF je väčšie ako 50 MB."}), 400

    encoded = base64.b64encode(data).decode("ascii")
    body = {
        "model": OPENAI_MODEL,
        "input": [{
            "role": "user",
            "content": [
                {
                    "type": "input_file",
                    "filename": f.filename,
                    "file_data": f"data:application/pdf;base64,{encoded}",
                    "detail": "high"
                },
                {"type": "input_text", "text": PROMPT}
            ]
        }],
        "text": {
            "format": {
                "type": "json_schema",
                "name": "floor_heating_project",
                "strict": True,
                "schema": SCHEMA
            }
        }
    }

    try:
        r = requests.post(
            "https://api.openai.com/v1/responses",
            headers={
                "Authorization": f"Bearer {OPENAI_API_KEY}",
                "Content-Type": "application/json"
            },
            json=body,
            timeout=180
        )
    except requests.RequestException as e:
        return jsonify({"error": f"Nepodarilo sa spojiť s AI službou: {e}"}), 502

    if not r.ok:
        try:
            detail = r.json()
        except Exception:
            detail = r.text[:1000]
        return jsonify({"error": "AI API vrátilo chybu.", "detail": detail}), r.status_code

    raw = r.json()
    text = extract_output_text(raw)
    if not text:
        return jsonify({"error": "AI nevrátila čitateľný výsledok.", "detail": raw}), 502

    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        return jsonify({"error": "AI výsledok nebol platný JSON.", "raw": text[:3000]}), 502

    return jsonify(parsed)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "8080")), debug=False)
